package servicio;

import modelo.Opcion;
import modelo.Pregunta;
import repositorio.BBDD;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ServicioBD {
    private final BBDD repo;

    public ServicioBD() throws SQLException {
        repo = new BBDD();
    }

    public void insertarPreguntas(List<Pregunta> preguntas) throws SQLException {
        Long idPregunta;
        String enunciado;
        Long idOpcion;
        String textoOpcion;
        Character charOpcion;
        boolean isOorrectaOpcion;

        for (Pregunta pregunta : preguntas) {
            idPregunta = pregunta.getId();
            enunciado = pregunta.getEnunciado();
            repo.ejecutarDML(String.format("INSERT INTO pregunta (ID, ENUNCIADO) VALUES (%d, '%s');", idPregunta, enunciado));
            for (Opcion opcion : pregunta.getOpciones()) {
                idOpcion = opcion.getId();
                textoOpcion = opcion.getTexto();
                charOpcion = opcion.getOpcion();
                isOorrectaOpcion = opcion.isEsCorrecta();
                repo.ejecutarDML(String.format("INSERT INTO opcion (ID, TEXTO, OPCION, CORRECTA, ID_PREGUNTA) VALUES (%d, '%s', '%c', %b, %d);",
                                    idOpcion, textoOpcion, charOpcion, isOorrectaOpcion, idPregunta));
            }
        }
    }

    public boolean esOpcionCorrecta(Character opcion, Long id_pregunta) throws SQLException {
        ResultSet resultSet;

        resultSet = repo.ejecutarQuery(String.format("SELECT CORRECTA FROM opcion WHERE OPCION LIKE '%c' AND ID_PREGUNTA = %d", opcion, id_pregunta));
        if (resultSet.next()) {
            return (resultSet.getBoolean("CORRECTA"));
        } else {
            throw new SQLException("No se ha encontrado esta opción en la bbdd.");
        }
    }

    public void eliminarContenidoSiHubiese() throws SQLException {
        repo.ejecutarDML("DELETE FROM pregunta;");
        repo.ejecutarDML("DELETE FROM opcion;");
    }
}
