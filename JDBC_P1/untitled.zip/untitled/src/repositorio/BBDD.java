package repositorio;

import utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BBDD {
    Connection conexion;

    public BBDD() throws SQLException {
        this.conexion = DBConnection.getConnection();
    }

    public void ejecutarDML(String sql) throws SQLException {
        PreparedStatement stmt = conexion.prepareStatement(sql);
        stmt.execute();
    }

    public ResultSet ejecutarQuery(String sql) throws SQLException {
        PreparedStatement stmt = conexion.prepareStatement(sql);
        return stmt.executeQuery();
    }
}
