package _6_excepciones;

public class LecturaEscrituraException extends RuntimeException {
    public LecturaEscrituraException(String message) {
        super(message);
    }
}
