package _6_excepciones;

public class EntidadNoEncontradaException extends ApplicationException {
    public EntidadNoEncontradaException(String message) {
        super(message);
    }
}
