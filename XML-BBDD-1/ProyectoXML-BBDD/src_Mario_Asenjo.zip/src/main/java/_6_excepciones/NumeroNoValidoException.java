package _6_excepciones;

public class NumeroNoValidoException extends RuntimeException {
    public NumeroNoValidoException(String message) {
        super(message);
    }
}
