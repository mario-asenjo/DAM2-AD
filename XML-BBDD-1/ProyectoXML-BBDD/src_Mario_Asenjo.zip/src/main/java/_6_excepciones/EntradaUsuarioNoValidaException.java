package _6_excepciones;

public class EntradaUsuarioNoValidaException extends ApplicationException {
    public EntradaUsuarioNoValidaException(String message) {
        super(message);
    }
}
