package _6_excepciones;

public class IdDuplicadoException extends ApplicationException {
    public IdDuplicadoException(String message) {
        super(message);
    }
}
