import _1_vista.PuntoEntrada;

public class Main {
    public static void main(String[] args) {
        PuntoEntrada puntoDeEntradaPrograma = new PuntoEntrada();

        puntoDeEntradaPrograma.iniciar();
    }
}
